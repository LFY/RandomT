from distutils.core import setup

setup(
        name='RandomT',
        version='1.0',
        author='Lingfeng Yang',
        author_email='lyang@cs.stanford.edu',

        packages=['RandomT','RandomT.samplers'],
)
